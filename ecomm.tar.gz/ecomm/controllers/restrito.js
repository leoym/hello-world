module.exports = function (app) {
 var RestritoController = {
 menu: function (request, response) {
     var usuario = request.session.usuario,
     params = { usuario: usuario };
     response.render('restrito/menu', params);
 },
 cadastroUsuario: function (request, response) {
     var usuario = request.session.usuario,
     params = { usuario: usuario };
 response.render('restrito/cadUsuario', params);
 },
 cadastroEmpresa: function (request, response) {
     var usuario = request.session.usuario,
     params = { usuario: usuario };
     response.render('restrito/cadEmpresa', params);
 },
 cadastroProduto: function (request, response) {
     var usuario = request.session.usuario,
     params = { usuario: usuario };
     response.render('restrito/cadProduto', params);
 },
 listaProdutos: function (request, response) {
     var usuario = request.session.usuario,
     params = { usuario: usuario };
     response.render('restrito/listaProdutos', params);
    },
 novoUsuario: function (request, response) {
     var nome = request.body.usuario.nome;
     var senha = request.body.usuario.senha;
     var confirma = request.body.usuario.confirma;

     //código a ser implementado

     var databaseUrl = "dados";
     var collections = ["usuarios"];
     var mongojs = require("mongojs");
     var db = mongojs("dados");

     // Cadastrando usuario
     console.log("");
     console.log("Cadastrando usuario");
     db.usuarios.save({nome: nome, senha: senha}, function(err, saved) {
            if( err || !saved )
                 console.log("Erro ao cadastrar usuario.");
            else 
                 console.log("Usuario cadastrado com sucesso." + nome);
     });
     db.close();

     //response.redirect('/menu'); 
     response.end('<p>Usuario cadastrado com sucesso</p><p><a href=menu>Menu</a></p>');
    },
 novaEmpresa: function (request, response) {
     var descricao = request.body.empresa.descricao;
     var nome = request.body.empresa.nome;
     var responsavel = request.body.empresa.responsavel;

     //código a ser implementado

     var databaseUrl = "dados";
     var collections = ["empresas"];
     var mongojs = require("mongojs");
     var db = mongojs("dados");

     // Cadastrando empresa
     console.log("");
     console.log("Cadastrando empresa");
     db.empresas.save({nome: nome, descricao: descricao, responsavel : responsavel}, function(err, saved) {
            if( err || !saved )
                 console.log("Erro ao cadastrar empresa.");
            else
                 console.log("Empresa cadastrado com sucesso.");
     });
     db.close();

     //response.redirect('/menu');
     response.end('<p>Empresa cadastrada com sucesso</p><p><a href=menu>Menu</a></p>');
    },
 novoProduto: function (request, response) {
     var descricao = request.body.produto.descricao;
     var nome = request.body.produto.nome;
     var responsavel = request.body.produto.responsavel;

     //código a ser implementado
     // Cadastrando produto

     var collections = ["produtos"];
     var mongojs = require("mongojs");
     var db = mongojs("dados");

     console.log("");
     console.log("Cadastrando produto");
     db.produtos.save({nome: nome, descricao: descricao, responsavel : responsavel}, function(err, saved) {
            if( err || !saved )
                 console.log("Erro ao cadastrar produto.");
            else
                 console.log("Produto cadastrado com sucesso.");
     });
     db.close();

     //response.redirect('/menu');
     response.end('<p>Produto cadastrado com sucesso</p><p><a href=menu>Menu</a></p>');
    }
 };

 return RestritoController;
response.end('<p>Usuario cadastrado com sucesso</p><p><a href=menu>Menu</a></p>');
}; 
