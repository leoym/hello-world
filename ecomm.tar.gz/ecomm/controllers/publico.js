module.exports = function (app) {
 var PublicoController = {
 empresas: function (req, res) {
    res.render('publico/empresas');
 },
 produtos: function (req, res) {
    res.render('publico/produtos');
 } 
 };
 return PublicoController;
}; 
