module.exports = function (app) {
 var publico = app.controllers.publico;
 app.get('/empresas', publico.empresas);
 app.get('/produtos', publico.produtos);
}; 
