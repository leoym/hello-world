module.exports = function (app) {
 var valida = require('./../middlewares/valida'); 
 var restrito = app.controllers.restrito;
 app.get('/menu', valida, restrito.menu);
 app.get('/cadUsuario', valida, restrito.cadastroUsuario);
 app.get('/cadEmpresa', valida, restrito.cadastroEmpresa);
 app.get('/cadProduto', valida, restrito.cadastroProduto);
 app.get('/listaProdutos', valida, restrito.listaProdutos);
 app.post('/novoUsuario', valida, restrito.novoUsuario); 
 app.post('/novaEmpresa', valida, restrito.novaEmpresa); 
 app.post('/novoProduto', valida, restrito.novoProduto); 
}; 
